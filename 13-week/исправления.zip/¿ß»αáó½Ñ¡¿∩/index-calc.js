// function getFirstOperand()
// {
//     let number1 = prompt('Введите первое число');
//     return number1;
// }

// function getTwoOperand()
// {
//     let number2 = prompt('Введите второе число');
//     return number2;
// }

// function calcSummation(number1,number2)
// {
//     return +number1 + +number2;
// }
// let result = calcSummation(number1,number2);

// function showResult(result)
// {
//     alert(result);
// }

// function calcSubtraction(number1, number2)
// {
//     return number1 - number2;
// }
// let result2 = calcSubtraction(number1, number2);


// function calcDivision(number1, number2)
// {
//     return number1 / number2;
// }
// let result3 = calcDivision(number1, number2);

// function calcMultiplication(number1, number2)
// {
//     return number1 * number2;
// }
// let result4 = calcMultiplication(number1, number2);

function divide() {
   let a = prompt('1-number?');
   let b = prompt('2-number?');
   return a / b;
}

